<?php

namespace App\Http\Controllers;
use App\Models\School;
use Illuminate\Http\Request;

class SchoolsApiController extends Controller
{
    public function index()
    {
        $response = School::with('classes.sections.students')->get();
        return response()->json($response, 200);
    }

    public function show($id)
    {
        return School::with('classes.sections.students')->find($id);
    }

    public function destroy(School $school)
    {
        $success = $school->delete();

        return [
            'success' => $success
        ];
    }
}
