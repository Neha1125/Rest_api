<!DOCTYPE html>
<html>
<body>

<h1>My First Heading</h1>
<p>My first paragraph.</p>

</body>
</html><?php /**PATH C:\xampp\htdocs\Client\laravel\api_task\resources\views/index.blade.php ENDPATH**/ ?>